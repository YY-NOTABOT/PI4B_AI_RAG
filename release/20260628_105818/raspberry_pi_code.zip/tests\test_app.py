from fastapi.testclient import TestClient

from app import app, deepseek_client, repository


client = TestClient(app)
deepseek_client.config.deepseek_api_key = ""
if repository.driver is not None:
    repository.driver.close()
repository.driver = None


def test_consult_returns_medical_guidance_for_common_symptoms():
    response = client.post("/api/consult", json={"query": "发烧、咳嗽、嗓子痛两天"})

    assert response.status_code == 200
    data = response.json()
    assert data["diseases"]
    assert data["medicines"]
    assert data["departments"]
    assert "确诊" in data["advice"]


def test_consult_rejects_empty_query():
    response = client.post("/api/consult", json={"query": "   "})

    assert response.status_code == 400
    assert response.json()["detail"] == "请输入症状描述。"


def test_consult_handles_unmatched_query():
    response = client.post("/api/consult", json={"query": "想了解社区活动安排"})

    assert response.status_code == 200
    data = response.json()
    assert data["diseases"] == []
    assert data["medicines"] == []
    assert data["departments"] == []
    assert "未在本地知识库中找到明确匹配" in data["advice"]


def test_voice_status_missing_file_is_safe():
    response = client.get("/api/voice/status")

    assert response.status_code == 200
    assert response.json()["state"]
