#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/home/yy-notabot/AI_RAG"
WEB_URL="http://127.0.0.1:8000"

echo "[1/5] Starting Neo4j..."
sudo systemctl start neo4j

echo "[2/5] Starting AI_RAG web service..."
sudo systemctl start airag-web

echo "[3/5] Starting ReSpeaker voice service..."
sudo systemctl start airag-voice

echo "[4/5] Checking service states..."
systemctl --no-pager --full status neo4j airag-web airag-voice | sed -n '1,80p'

echo "[5/5] Checking HTTP endpoints..."
python3 - <<'PY'
import json
import sys
import time
import urllib.request

base = "http://127.0.0.1:8000"
for _ in range(30):
    try:
        with urllib.request.urlopen(base + "/", timeout=2) as response:
            if response.status == 200:
                break
    except Exception:
        time.sleep(1)
else:
    print("Web service did not become ready at http://127.0.0.1:8000", file=sys.stderr)
    sys.exit(1)

with urllib.request.urlopen(base + "/api/voice/status", timeout=5) as response:
    payload = json.loads(response.read().decode("utf-8"))
print("voice_status:", json.dumps(payload, ensure_ascii=False))
PY

echo
echo "All services are started."
echo "Open: http://100.88.185.67:8000"
